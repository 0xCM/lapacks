module Foreign.Storable.Complex () where

import Data.Orphans()
