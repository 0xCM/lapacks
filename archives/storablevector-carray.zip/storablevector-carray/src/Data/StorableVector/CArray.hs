{-# LANGUAGE Trustworthy #-}
module Data.StorableVector.CArray where

import qualified Data.StorableVector.Base as SV
import qualified Data.StorableVector as V

import qualified Data.Array.CArray.Base as CArray

import Foreign.Storable (Storable, )

import Data.Tuple.HT (swap, snd3, )



to :: (Storable e) =>
   SV.Vector e -> CArray.CArray Int e
to v =
   let checkZeroBase vf else_ =
          let vo = SV.toForeignPtr vf
          in  if snd3 vo == 0
                then vo
                else else_
       (ptr, _s, l) =
          checkZeroBase v $
          checkZeroBase (V.copy v) $
          error "StorableVectorCArray.to: we expect that StorableVector.copy generates a 0-based vector"
   in  CArray.CArray 0 (l-1) l ptr
{-
   CArray.unsafeForeignPtrToCArray
      (advancePtr s ptr) (0,l-1)
-}

from :: (Storable e) =>
   CArray.CArray Int e -> SV.Vector e
from =
   uncurry SV.fromForeignPtr . swap . CArray.toForeignPtr
