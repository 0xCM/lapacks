{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.LAPACK.FFI.Float where

import Foreign.Ptr (FunPtr, Ptr)
import Foreign.C.Types

