{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.LAPACK.FFI.Miscellaneous where

import Foreign.Ptr (Ptr)
import Foreign.C.Types

