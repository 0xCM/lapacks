{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.LAPACK.FFI.Double where

import Foreign.Ptr (FunPtr, Ptr)
import Foreign.C.Types

