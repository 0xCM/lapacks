{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.LAPACK.FFI.ComplexDouble where

import Data.Complex (Complex)
import Foreign.Ptr (FunPtr, Ptr)
import Foreign.C.Types

