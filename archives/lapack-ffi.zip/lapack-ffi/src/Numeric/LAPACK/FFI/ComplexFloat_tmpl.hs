{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.LAPACK.FFI.ComplexFloat where

import Data.Complex (Complex)
import Foreign.Ptr (FunPtr, Ptr)
import Foreign.C.Types

