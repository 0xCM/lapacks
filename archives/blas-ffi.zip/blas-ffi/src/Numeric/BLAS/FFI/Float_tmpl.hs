{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.BLAS.FFI.Float where

import Foreign.Ptr (Ptr)
import Foreign.C.Types

