module Numeric.BLAS.FFI.Real where

import qualified Numeric.BLAS.FFI.Float as S
import qualified Numeric.BLAS.FFI.Double as D

import qualified Numeric.Netlib.Class as Class

import Foreign.Ptr (Ptr)
import Foreign.C.Types

