{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.BLAS.FFI.Double where

import Foreign.Ptr (Ptr)
import Foreign.C.Types

