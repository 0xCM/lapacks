{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.BLAS.FFI.ComplexFloat where

import Data.Complex (Complex)
import Foreign.Ptr (Ptr)
import Foreign.C.Types

