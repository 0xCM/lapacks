{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.BLAS.FFI.ComplexDouble where

import Data.Complex (Complex)
import Foreign.Ptr (Ptr)
import Foreign.C.Types

