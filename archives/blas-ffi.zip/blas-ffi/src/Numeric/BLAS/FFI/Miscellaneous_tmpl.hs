{-# LANGUAGE ForeignFunctionInterface #-}
module Numeric.BLAS.FFI.Miscellaneous where

import Foreign.Ptr (Ptr)
import Foreign.C.Types

