module Type.Data.Num.Decimal
    ( module Type.Data.Num.Decimal.Literal
    , module Type.Data.Num.Decimal.Number
    ) where

import Type.Data.Num.Decimal.Literal
import Type.Data.Num.Decimal.Number
