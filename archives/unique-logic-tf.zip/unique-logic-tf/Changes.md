## 0.5

 * `ZeroFractional` class

 * generalize from `ST` monad to any monad supporting mutable references
   using `data-ref` package
