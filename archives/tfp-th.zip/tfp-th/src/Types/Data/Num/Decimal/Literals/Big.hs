{-# LANGUAGE TemplateHaskell #-}
module Types.Data.Num.Decimal.Literals.Big where

import Types.Data.Num.Decimal.Literals.TH

$( decLiteralsD "D" "d" (-10000) (10000) )
