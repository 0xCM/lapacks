{- | Access helper functions in a State monad -}
module Data.Accessor.MonadState
   {-# DEPRECATED "please use Data.Accessor.Monad.Trans.State from data-accessor-transformers" #-}
   (module Data.Accessor.MonadStatePrivate)
   where

import Data.Accessor.MonadStatePrivate
